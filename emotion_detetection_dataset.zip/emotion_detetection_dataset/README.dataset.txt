# Emotion Recognition YOLO v11 FYP 2 > 2024-11-04 7:34pm
https://universe.roboflow.com/yip-chun-kit-y2buh/emotion-recognition-yolo-v11-fyp-2

Provided by a Roboflow user
License: CC BY 4.0

